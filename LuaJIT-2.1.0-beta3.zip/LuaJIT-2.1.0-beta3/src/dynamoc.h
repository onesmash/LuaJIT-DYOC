/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   dynamoc.h
 * Author: xuhui
 *
 * Created on 2017年12月18日, 下午3:19
 */

#ifndef DYNAMOC_H
#define DYNAMOC_H

#ifdef __cplusplus
extern "C" {
#endif
    
void dyoc_register_sym(const char* name, void* sym);
void* dyoc_find_sym(const char* name);
    
#ifdef __cplusplus
}
#endif

#endif /* DYNAMOC_H */
