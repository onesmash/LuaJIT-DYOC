/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   dynamoc.cpp
 * Author: xuhui
 * 
 * Created on 2017年12月18日, 下午3:19
 */

#include "dynamoc.h"
#include <string>
#include <unordered_map>
using namespace std;

static unordered_map<string, void*> sym_map;

#ifdef __cplusplus
extern "C" {
#endif

void dyoc_register_sym(const char* name, void* sym)
{
    sym_map.erase(name);
    sym_map.insert({{name, sym}});
}

void* dyoc_find_sym(const char* name)
{
    auto iter = sym_map.find(name);
    if(iter != sym_map.end()) {
        return iter->second;
    } else {
        return NULL;
    }
}

#ifdef __cplusplus
}
#endif
